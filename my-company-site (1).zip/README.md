# وب‌سایت شرکتی با Next.js

برای اجرا:

```bash
npm install
npm run dev
```