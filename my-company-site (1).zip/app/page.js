export default function Page() {
  return (
    <main style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>به وب‌سایت رسمی شرکت ما خوش آمدید!</h1>
    </main>
  );
}