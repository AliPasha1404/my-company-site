export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow p-4 sticky top-0 z-50">
        <nav className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">نام شرکت</h1>
          <ul className="flex gap-6 text-sm font-medium">
            <li>خانه</li>
            <li>درباره ما</li>
            <li>خدمات</li>
            <li>محصولات</li>
            <li>پروژه‌ها</li>
            <li>مقالات</li>
            <li>تماس با ما</li>
          </ul>
        </nav>
      </header>

      <section className="bg-blue-50 py-20 text-center">
        <h2 className="text-4xl font-bold mb-4">به وب‌سایت رسمی ما خوش آمدید</h2>
        <p className="text-gray-600 max-w-xl mx-auto">
          ما ارائه‌دهنده بهترین خدمات و راه‌حل‌ها برای رشد کسب‌وکار شما هستیم.
        </p>
      </section>

      <section className="py-16">
        <div className="container mx-auto text-center">
          <h3 className="text-3xl font-semibold mb-10">خدمات ما</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white shadow rounded-2xl p-6">
              <h4 className="text-xl font-bold mb-2">مشاوره کسب‌وکار</h4>
              <p className="text-sm text-gray-600">
                راهکارهای تخصصی برای رشد و توسعه کسب‌وکار شما
              </p>
            </div>
            <div className="bg-white shadow rounded-2xl p-6">
              <h4 className="text-xl font-bold mb-2">طراحی وب‌سایت</h4>
              <p className="text-sm text-gray-600">
                طراحی سایت‌های حرفه‌ای با تمرکز بر تجربه کاربری
              </p>
            </div>
            <div className="bg-white shadow rounded-2xl p-6">
              <h4 className="text-xl font-bold mb-2">دیجیتال مارکتینگ</h4>
              <p className="text-sm text-gray-600">
                تبلیغات آنلاین، سئو و استراتژی‌های دیجیتال برای افزایش فروش
              </p>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="container mx-auto text-center text-sm">
          © {new Date().getFullYear()} نام شرکت. تمام حقوق محفوظ است.
        </div>
      </footer>
    </main>
  );
}
